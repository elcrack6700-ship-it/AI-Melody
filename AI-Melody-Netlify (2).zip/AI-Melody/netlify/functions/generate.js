exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Método no permitido." })
    };
  }

  try {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: "Falta configurar OPENAI_API_KEY en las variables de entorno de Netlify."
        })
      };
    }

    let data;
    try {
      data = JSON.parse(event.body || "{}");
    } catch {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "El contenido enviado no es válido." })
      };
    }

    const action = String(data.action || "");
    const lyrics = String(data.lyrics || "").slice(0, 6000);
    const style = String(data.style || "").slice(0, 1000);
    const title = String(data.title || "").slice(0, 150);
    const instrumental = Boolean(data.instrumental);
    const mode = String(data.mode || "Custom").slice(0, 30);
    const options = Array.isArray(data.options)
      ? data.options.map(x => String(x).slice(0, 30)).slice(0, 3)
      : [];

    let instructions;

    if (action === "lyrics") {
      instructions = instrumental
        ? "Crea una propuesta instrumental original en español. No escribas letra cantada. Describe ambiente, estructura, instrumentos, ritmo y dinámica."
        : "Escribe una canción completamente original en español. Incluye título, versos, pre-coro si encaja, coro y puente. No imites artistas ni copies letras protegidas.";
    } else if (action === "optimize") {
      if (!lyrics.trim()) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Escribe una letra antes de optimizarla." })
        };
      }
      instructions = "Edita y mejora la letra proporcionada conservando su significado, historia y emoción. Mejora fluidez, rimas y estructura. No copies canciones existentes. Devuelve la letra revisada y nada más.";
    } else if (action === "idea") {
      instructions = "Prepara una propuesta de canción original. Incluye título sugerido, concepto, género, instrumentos, ritmo, ambiente y estructura. Si el usuario proporcionó letra, úsala como referencia. No afirmes que has generado un archivo de audio.";
    } else {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Acción desconocida." })
      };
    }

    const input = [
      "Modo de trabajo: " + mode,
      "Título: " + (title || "Sin título"),
      "Estilo musical: " + (style || "Libre"),
      "Instrumental: " + (instrumental ? "Sí" : "No"),
      "Opciones seleccionadas: " + (options.join(", ") || "Ninguna"),
      "Letra o material del usuario:\n" + (lyrics || "No proporcionado")
    ].join("\n\n");

    const openaiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions,
        input,
        max_output_tokens: 1800
      })
    });

    const result = await openaiResponse.json();

    if (!openaiResponse.ok) {
      console.error("OpenAI API error:", result);
      return {
        statusCode: openaiResponse.status === 429 ? 429 : 502,
        headers,
        body: JSON.stringify({
          error: openaiResponse.status === 429
            ? "Se alcanzó un límite de uso. Inténtalo más tarde."
            : "OpenAI no pudo completar la solicitud. Revisa la configuración de la API."
        })
      };
    }

    const outputText = result.output_text;
    if (!outputText) {
      throw new Error("OpenAI no devolvió texto.");
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        text: outputText,
        message: "¡AI Melody creó tu contenido! 🎵"
      })
    };
  } catch (error) {
    console.error("AI Melody function error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Ocurrió un error en el servidor. Inténtalo de nuevo."
      })
    };
  }
};
